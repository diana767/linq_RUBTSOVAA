﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Security.Cryptography;

namespace DZ_RUBTSOVA
{
    public partial class Form1 : Form
    {
        List<Pp> people = new List<Pp>();
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] lines = File.ReadAllLines(file);
                Pp h = new Pp("", "", "", 0, 0);
                foreach (string line in lines)
                {
                    string[] chel = line.Split(' ');
                    string inname = chel[0];
                    h.set_inname(inname);
                    string name = chel[1];
                    h.set_name(name);
                    string otch = chel[2];
                    h.set_otch(otch);
                    int age = Convert.ToInt32(chel[3]);
                    h.set_age(age);
                    double weidth = Convert.ToDouble(chel[4]);
                    h.set_weidth(weidth);
                    string f = $"{h.get_inname()} {h.get_name()} {h.get_otch()} {h.get_age()} {h.get_weidth()}\n\n\n";
                    listBox1.Items.Add(f);
                    people.Add(new Pp(inname, name, otch, age, weidth));
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            var b = from p in people
                    where Convert.ToInt32(p.get_age()) < 40
                    select p;
            foreach (var a in b)
            {
                string f1 = $"ФИО: {a.get_inname()}  {a.get_name()}  {a.get_otch()}  \nВозраст:  {a.get_age()} \n Вес: {a.get_weidth()}\n\n\n";
                listBox2.Items.Add(f1);
            }
        }
    }
}
