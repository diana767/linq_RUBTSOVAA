﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DZ_RUBTSOVA
{
    internal class Pp
    {
            private string inname;
            private string name;
            private string otch;
            private int age;
            private double weidth;

            public Pp(string inname, string name, string otch, int age, double weidth)
            {
                this.inname = inname;
                this.name = name;
                this.otch = otch;
                this.age = age;
                this.weidth = weidth;
            }
            public void set_inname(string n)
            {
                this.inname = n;
            }
            public string get_inname()
            {
                return inname;
            }
            public void set_name(string n)
            {
                this.name = n;
            }
            public string get_name()
            {
                return this.name;
            }
            public void set_otch(string n)
            {
                this.otch = n;
            }
            public string get_otch()
            {
                return this.otch;
            }
            public void set_age(int n)
            {
                this.age = n;
            }
            public int get_age()
            {
                return this.age;
            }
            public void set_weidth(double n)
            {
                this.weidth = n;
            }
            public double get_weidth()
            {
                return this.weidth;
            }
        }
    
}
